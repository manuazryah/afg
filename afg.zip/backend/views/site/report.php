<?php

use yii\helpers\Html;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<table class="ia table table-striped table-bordered" width="100%">
    <tbody>
        <tr>
            <th width="20%" align="center" id="pipi"><b>Inventory</b>
            </th><th><b>ABDUL SHUKOOR MUHAMAD CARS TR.LLC</b>
            </th><th width="12%" align="right"><b>Sort Type:</b>
            </th><th width="15%">On hand
            </th><th width="15%" align="center">
                <b>Location
                    <b>
                    </b></b></th>
            <th width="15%">NY
            </th></tr>
    </tbody>
</table>
<table width="100%" class="ia table table-striped table-bordered" border="1" style="border:solid 1px;">
    <tbody>
        <tr>
            <th>HAT NO</th>
            <th>DATE RECEIVED</th>
            <th>YEAR</th>
            <th>MAKE</th>
            <th>MODEL</th>
            <th>COLOR</th>
            <th>VIN</th>
            <th>TITLE</th>
            <th>TITLE TYPE</th>
            <th>KEYS</th>
            <th>AGE</th>
            <th>STATUS</th>
            <th>NOTE</th>
        </tr><tr align="center"><td>496</td>
            <td>2017-03-30</td>
            <td>2003</td>
            <td>TOYOTA</td>
            <td>AVALON</td>
            <td>WHITE</td>
            <td>4T1BF28B83U302766</td>
            <td>YES</td>
            <td>NO-TITLE</td>
            <td>YES</td>
            <td>117</td>
            <td>ON HAND</td>
            <td></td>
        </tr></tbody></table>

